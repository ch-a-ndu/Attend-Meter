package com.example.chandu.attendapp;

import android.support.annotation.NonNull;
import android.support.v7.recyclerview.extensions.ListAdapter;
import android.support.v7.util.DiffUtil;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class SubjectAdapter extends ListAdapter<Subject,SubjectAdapter.SubjectHolder> {


    private onCilckItemListener listener;

    public SubjectAdapter() {
        super(DIFF_CALLBACK);
    }

    private static final DiffUtil.ItemCallback<Subject> DIFF_CALLBACK=new DiffUtil.ItemCallback<Subject>() {
        @Override
        public boolean areItemsTheSame(@NonNull Subject subject, @NonNull Subject t1) {
            return subject.getId()==t1.getId();
        }

        @Override
        public boolean areContentsTheSame(@NonNull Subject subject, @NonNull Subject t1) {
            return subject.getTitle().equals(t1.getTitle())&&
                    subject.getTotal()==t1.getTotal()&&
                    subject.getAttended()==t1.getAttended();
        }
    };

    @NonNull
    @Override
    public SubjectHolder onCreateViewHolder(@NonNull ViewGroup parent, int i) {
        View itemView= LayoutInflater.from(parent.getContext())
                .inflate(R.layout.subject_item,parent,false);
        return new SubjectHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull SubjectHolder holder, int position) {
        Subject currentSubject = getItem(position);
        holder.tvTitle.setText(currentSubject.getTitle());
        holder.tvAttend.setText(String.valueOf(currentSubject.getAttended()));
        holder.tvTotal.setText(String.valueOf(currentSubject.getTotal()));

    }





    public Subject subjectAt(int position){
        return getItem(position);
    }

    class SubjectHolder extends RecyclerView.ViewHolder{
        private TextView tvTitle;
        private TextView tvAttend;
        private TextView tvTotal;

        public SubjectHolder(@NonNull View itemView) {
            super(itemView);
            tvTitle=itemView.findViewById(R.id.title_tv);
            tvAttend=itemView.findViewById(R.id.attend_tv);
            tvTotal=itemView.findViewById(R.id.total_tv);

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    int position = getAdapterPosition();
                    if(listener!=null&&position!=RecyclerView.NO_POSITION) {
                        listener.itemClick(getItem(position));
                    }
                }
            });
        }
    }

    public interface onCilckItemListener{
        void itemClick(Subject subject);
    }

    public void setOnClickItemListener(onCilckItemListener listener){
        this.listener=listener;
    }
}
