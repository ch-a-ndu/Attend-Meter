package com.example.chandu.attendapp;

import android.app.Dialog;
import android.arch.lifecycle.Observer;
import android.arch.lifecycle.ViewModelProviders;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.helper.ItemTouchHelper;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private SubjectViewModel subjectViewModel;
    public static final int Set_ok = 3;
    public static final int Up_ok = 4;
    public static final int Add_req = 1;
    public static final int Up_req = 2;
    int ut, ua, uid;
    public String uti;
    public Dialog epic;
    public TextView tv, tv1, tv2;
    public ImageView close75, close65, closed, closeabt;
    private List<Subject> allsubs = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        epic = new Dialog(this);

        FloatingActionButton buttonadd = findViewById(R.id.fab);
        buttonadd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, Add_Sub.class);
                startActivityForResult(intent, Add_req);
            }
        });

        RecyclerView recyclerView = findViewById(R.id.re_view);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setHasFixedSize(true);

        final SubjectAdapter adapter = new SubjectAdapter();
        recyclerView.setAdapter(adapter);

        subjectViewModel = ViewModelProviders.of(this).get(SubjectViewModel.class);
        subjectViewModel.getallsubs().observe(this, new Observer<List<Subject>>() {
            @Override
            public void onChanged(@Nullable List<Subject> subjects) {
                adapter.submitList(subjects);

            }
        });


        new ItemTouchHelper(new ItemTouchHelper.SimpleCallback(0,
                ItemTouchHelper.RIGHT) {
            @Override
            public boolean onMove(@NonNull RecyclerView recyclerView, @NonNull RecyclerView.ViewHolder viewHolder, @NonNull RecyclerView.ViewHolder viewHolder1) {
                return false;
            }

            @Override
            public void onSwiped(@NonNull final RecyclerView.ViewHolder viewHolder, int i) {

                AlertDialog.Builder alert = new AlertDialog.Builder(MainActivity.this);
                alert.setTitle("Sure, Are Want To Delete? ");
                alert.setPositiveButton("yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        subjectViewModel.delete(adapter.subjectAt(viewHolder.getAdapterPosition()));
                        Toast.makeText(MainActivity.this, "Subject Deleted", Toast.LENGTH_LONG).show();
                    }
                });
                alert.setNegativeButton("no", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        adapter.notifyItemChanged(viewHolder.getAdapterPosition());
                    }
                });
                alert.create().show();

            }
        }).attachToRecyclerView(recyclerView);

        adapter.setOnClickItemListener(new SubjectAdapter.onCilckItemListener() {
            @Override
            public void itemClick(Subject subject) {
                uid = subject.getId();
                ut = subject.getTotal();
                ua = subject.getAttended();
                uti = subject.getTitle();
                Intent intent = new Intent(MainActivity.this, UpdateSub.class);
                intent.putExtra(UpdateSub.Extra_upid, uid);
                intent.putExtra(UpdateSub.Extra_uptitle, uti);
                intent.putExtra(UpdateSub.Extra_uptotal, ut);
                intent.putExtra(UpdateSub.Extra_upattend, ua);
                startActivityForResult(intent, Up_req);

            }
        });
    }

    public float genReport() {
        Subject subject;
        float reptot = 0, repatt = 0;
        float rep;
        allsubs = subjectViewModel.getallsubs().getValue();
        int i = allsubs.size();
        for (int j = 0; j < i; j++) {
            subject = allsubs.get(j);
            reptot = reptot + subject.getTotal();
            repatt = repatt + subject.getAttended();
        }
        rep = repatt / reptot;
        return rep * 100;

    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {


        if (requestCode == Add_req && resultCode == Set_ok) {
            super.onActivityResult(requestCode, resultCode, data);
            String title = data.getStringExtra(Add_Sub.Extra_title);
            int total = data.getIntExtra(Add_Sub.Extra_total, 1);
            int attend = data.getIntExtra(Add_Sub.Extra_attend, 1);

            Subject subject = new Subject(title, total, attend);
            subjectViewModel.insert(subject);

            Toast.makeText(this, "Subject Saved", Toast.LENGTH_SHORT).show();
        } else if (requestCode == Up_req && resultCode == Up_ok) {

            super.onActivityResult(requestCode, resultCode, data);
            int id = data.getIntExtra(UpdateSub.Extra_upid, -1);

            if (id == -1) {
                Toast.makeText(this, "Attendance can not be updated", Toast.LENGTH_SHORT).show();
                return;
            }


            int t = data.getIntExtra(UpdateSub.Extra_uptotal, 1);
            int a = data.getIntExtra(UpdateSub.Extra_upattend, 1);
            ut = ut + t;
            ua = ua + a;
            Subject subject = new Subject(uti, ut, ua);
            subject.setId(id);
            subjectViewModel.update(subject);
            Toast.makeText(this, "Attendance updated", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Subject not Saved", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.main_main, menu);

        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch (item.getItemId()) {
            case R.id.rpt_id:
                float percentage = genReport();
                if (percentage >= 75) {
                    epic.setContentView(R.layout.above75);
                    tv = (TextView) epic.findViewById(R.id.per75);
                    tv.setText("" + percentage + "%");
                    close75 = (ImageView) epic.findViewById(R.id.close75);
                    close75.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            epic.dismiss();
                        }
                    });
                    epic.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                    epic.show();
                } else if (percentage <= 65) {
                    epic.setContentView(R.layout.detain);
                    tv1 = (TextView) epic.findViewById(R.id.perD);
                    tv1.setText("" + percentage + "%");
                    closed = (ImageView) epic.findViewById(R.id.closed);
                    closed.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            epic.dismiss();
                        }
                    });
                    epic.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                    epic.show();
                } else {
                    epic.setContentView(R.layout.above65);
                    tv2 = (TextView) epic.findViewById(R.id.per65);
                    tv2.setText("" + percentage + "%");
                    close65 = epic.findViewById(R.id.close65);
                    close65.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            epic.dismiss();
                        }
                    });
                    epic.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                    epic.show();
                }
                return true;
            case R.id.abt:
                epic.setContentView(R.layout.about);
                closeabt = epic.findViewById(R.id.closeabt);
                closeabt.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        epic.dismiss();
                    }
                });
                epic.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                epic.show();
                return true;
            default:
                Toast.makeText(this, "not generatd", Toast.LENGTH_SHORT).show();
                return super.onOptionsItemSelected(item);

        }
    }
}